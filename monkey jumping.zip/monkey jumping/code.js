var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b","4ae8cbc3-5e74-40a2-bab5-e593124932d1","f88083c6-5591-4b31-8b5d-f99e4d861912","db8d07b6-e5b2-4857-b27b-aa14d8184412"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"m","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":9,"looping":true,"frameDelay":12,"version":"lRl4ihQrLnsj41bqp64FAYXWplSNyg2X","loadedFromSource":true,"saved":true,"sourceSize":{"x":1680,"y":1842},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"b","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png","frameSize":{"x":1080,"y":1080},"frameCount":1,"looping":true,"frameDelay":4,"version":"239dmhovVQGI.RTp2g6HksM9tJiFofJt","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":1080},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"s","sourceUrl":null,"frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":12,"version":"_6IHCqQE_zsoJHCmEntw0SKReKQABRvA","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/33841f90-7a53-4346-b956-e51d1961959b.png"},"4ae8cbc3-5e74-40a2-bab5-e593124932d1":{"name":"p","sourceUrl":"assets/api/v1/animation-library/gamelab/z8Dgk.em0WaIbb.0CaPSgLIoJa8HoEZe/category_backgrounds/pine_trees.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"z8Dgk.em0WaIbb.0CaPSgLIoJa8HoEZe","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/z8Dgk.em0WaIbb.0CaPSgLIoJa8HoEZe/category_backgrounds/pine_trees.png"},"f88083c6-5591-4b31-8b5d-f99e4d861912":{"name":"d","sourceUrl":"assets/v3/animations/unzoKcwvZOzx0uRV7_P5pj2BC1xIScCQ5pYVgBdw9nM/f88083c6-5591-4b31-8b5d-f99e4d861912.png","frameSize":{"x":299,"y":168},"frameCount":1,"looping":true,"frameDelay":4,"version":"KuQWMN.QoiBXGweCmn11BKILrqRfKuVq","loadedFromSource":true,"saved":true,"sourceSize":{"x":299,"y":168},"rootRelativePath":"assets/v3/animations/unzoKcwvZOzx0uRV7_P5pj2BC1xIScCQ5pYVgBdw9nM/f88083c6-5591-4b31-8b5d-f99e4d861912.png"},"db8d07b6-e5b2-4857-b27b-aa14d8184412":{"name":"do","sourceUrl":"assets/v3/animations/unzoKcwvZOzx0uRV7_P5pj2BC1xIScCQ5pYVgBdw9nM/db8d07b6-e5b2-4857-b27b-aa14d8184412.png","frameSize":{"x":216,"y":233},"frameCount":1,"looping":true,"frameDelay":4,"version":"7ycjQXI.BwxEAsa.nYkwwhCqBspAgLaz","loadedFromSource":true,"saved":true,"sourceSize":{"x":216,"y":233},"rootRelativePath":"assets/v3/animations/unzoKcwvZOzx0uRV7_P5pj2BC1xIScCQ5pYVgBdw9nM/db8d07b6-e5b2-4857-b27b-aa14d8184412.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var bg = createSprite(200,200,202,20);
bg.setAnimation("p");
bg.scale = 2;
bg.velocityX=-2;


var PLAY = 1;
var END = 0;
var gameState = 1;


var monkey = createSprite(70,350,20,20);
monkey.setAnimation("m");
monkey.scale = 0.19;

monkey.setCollider("circle",0,0,30);

var ground = createSprite(280,400,800,5);
ground.x = ground.width/2;
ground.velocityX = -2;

var invisibleground = createSprite(200,350,400,5);
invisibleground.visible = false;

var bananaGroup = createGroup();
var obstacleGroup = createGroup();
var count = 0;



function draw() {
  
  background(255);
  if (bg.x <0) {
bg.x = bg.width/2;
}
  
   monkey.collide(invisibleground);
  if(keyDown("space")){
     monkey.velocityY = -14;
    }
 
 if(gameState === PLAY){
    
    
    //scoring
    
   
    
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
    
  monkey.velocityY = monkey.velocityY + 0.8;
  
  if (ground.x < 0){
      ground.x = ground.width/2;
     
    }
     if (monkey.isTouching(bananaGroup)){
        bananaGroup.destroyEach();
        count = count + 2;
        
      }
      if (count === 10){
        monkey.scale = 0.25;
      }
      if (count === 30){
        monkey.scale = 0.32;
      }
      if (count === 50){
        monkey.scale = 0.35;
      }
      if (count === 60){
        monkey.setAnimation("do");
        monkey.scale = 3;
      }
  if(obstacleGroup.isTouching(monkey)){
    gameState = END;
  }
}
else if (gameState===END){
  bananaGroup.destroyEach();
  obstacleGroup.destroyEach();
  bg.velocityX = 0;
  monkey.setAnimation("d");
  monkey.x = 200;
  monkey.y = 200;
  monkey.scale = 3;
}
drawSprites();
textSize(30);
    text("score:"+ count,270,30);
  bananas  ();
  obstacles();
  

}
function bananas (){
  if (World.frameCount%100===0){
    
 
  var banana = createSprite(368,350,20,20);
  banana.setAnimation("b");
  banana.scale = 0.1;
  banana.velocityX = -3;
  var rand = randomNumber(120,200);
  banana.y = rand;
  bananaGroup.add(banana);
  }
}
function obstacles(){
  if (World.frameCount%80===0){
    
  
  var obstacle = createSprite(368,380,20,20);
  obstacle.setAnimation("s");
  obstacle.scale = 0.2;
  obstacle.velocityX = -4;
  obstacleGroup.add(obstacle);
  }
}

  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
